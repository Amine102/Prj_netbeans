/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys_enchere;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author BLHA
 */
public class FXMLController implements Initializable {

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @FXML
    private PasswordField box_connection_pass;

    @FXML
    private TextField box_connection_mail;

    @FXML
    private Button btn_connection;

    @FXML
    private TextField box_inscript_nom;

    @FXML
    private TextField box_inscript_prenom;

    @FXML
    private TextField box_inscript_mail;

    @FXML
    private PasswordField box_inscript_pass;

    @FXML
    private CheckBox check_affich_pass;

    @FXML
    private Button btn_inscription;

    @FXML
    private Label error_connect_label;

    @FXML
    private CheckBox check_accept_conditions;
    private enchere_database db;

    public static void println_data(ResultSet rs) throws SQLException {//Print Data inside a variable of type ResultSet
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        for (int i = 1; i <= columnsNumber; i++) {
            if (i > 1) {
                System.out.print(",  ");
            }
            String columnValue = rs.getString(i);
            System.out.print(columnValue + " " + rsmd.getColumnName(i));
        }
        System.out.println("");
    }

    public static boolean isEmptyResultSet(ResultSet rsCheck) {
        boolean empty = false;
        try {
            if (rsCheck.next()) {
                empty = false;
            } else {
                empty = true;
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return empty;
    }

    @FXML
    void aide_util(ActionEvent event) {

    }

    private void set_btn_connection_active() {
        box_connection_mail.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_connection_mail.getText() == null
                    || box_connection_mail.getText().trim().isEmpty())
                    || box_connection_pass.getText() == null)
                    || box_connection_pass.getText().trim().isEmpty());
            btn_connection.setDisable(isDisabled);
        });
        box_connection_pass.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_connection_mail.getText() == null
                    || box_connection_mail.getText().trim().isEmpty())
                    || box_connection_pass.getText() == null)
                    || box_connection_pass.getText().trim().isEmpty());
            btn_connection.setDisable(isDisabled);
        });

    }

    private void set_btn_inscript_active() {
        box_inscript_nom.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_inscript_nom.getText() == null
                    || box_inscript_nom.getText().trim().isEmpty())
                    || box_inscript_prenom.getText() == null)
                    || box_inscript_prenom.getText().trim().isEmpty())
                    || box_inscript_mail.getText() == null
                    || box_inscript_mail.getText().trim().isEmpty()
                    || box_inscript_pass.getText() == null
                    || box_inscript_pass.getText().trim().isEmpty();
            btn_inscription.setDisable(isDisabled);
        });
        box_inscript_prenom.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_inscript_nom.getText() == null
                    || box_inscript_nom.getText().trim().isEmpty())
                    || box_inscript_prenom.getText() == null)
                    || box_inscript_prenom.getText().trim().isEmpty())
                    || box_inscript_mail.getText() == null
                    || box_inscript_mail.getText().trim().isEmpty()
                    || box_inscript_pass.getText() == null
                    || box_inscript_pass.getText().trim().isEmpty();
            btn_inscription.setDisable(isDisabled);
        });
        box_inscript_mail.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_inscript_nom.getText() == null
                    || box_inscript_nom.getText().trim().isEmpty())
                    || box_inscript_prenom.getText() == null)
                    || box_inscript_prenom.getText().trim().isEmpty())
                    || box_inscript_mail.getText() == null
                    || box_inscript_mail.getText().trim().isEmpty()
                    || box_inscript_pass.getText() == null
                    || box_inscript_pass.getText().trim().isEmpty();
            btn_inscription.setDisable(isDisabled);
        });
        box_inscript_pass.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            boolean isDisabled = (((box_inscript_nom.getText() == null
                    || box_inscript_nom.getText().trim().isEmpty())
                    || box_inscript_prenom.getText() == null)
                    || box_inscript_prenom.getText().trim().isEmpty())
                    || box_inscript_mail.getText() == null
                    || box_inscript_mail.getText().trim().isEmpty()
                    || box_inscript_pass.getText() == null
                    || box_inscript_pass.getText().trim().isEmpty();
            btn_inscription.setDisable(isDisabled);
        });

    }

    @FXML
    void connection_util(ActionEvent event) throws SQLException, Exception {
        error_connect_label.setText("");
        String verif_mail = box_connection_mail.getText();
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$"; //expression stricte d'une adresse mail 
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(verif_mail);
        if (!matcher.matches()) {
            System.err.println("SYNTAX ERROR: Expression d'adresse mail incorrecte: veuillez saisir une adresse mail valide (ex. exemple@domaine.org).\n");
            error_connect_label.setText("Expression d'adresse mail incorrecte: veuillez saisir une adresse mail valide (ex. exemple@domaine.org).");

        } else {
            Connection conn = db.activate_connection(); //Creation d'une connection a la base
            Statement stmt = conn.createStatement();       //Creation d'une requête SQL
            ResultSet rs = stmt.executeQuery("SELECT adresse_mail FROM Utilisateur WHERE adresse_mail='" + verif_mail + "'");
            if (isEmptyResultSet(rs)) {
                String error = "l'adresse mail " + verif_mail + " n'existe pas dans notre base de donnée, veuillez vous enregistrer afin de bénificier de nos services.";
                System.err.println("SYNTAX ERROR: " + error + "\n");
                int MAX_LENGTH = 165;
                int DEFAULT_FONT = 13;
                if (error.length() % MAX_LENGTH == 0) {
                    error_connect_label.setFont(new Font((MAX_LENGTH - error.length()) + DEFAULT_FONT));
                } else {
                    error_connect_label.setFont(new Font(DEFAULT_FONT));
                }
                System.out.println("length= " + error.length());
                error_connect_label.setText(error);

            } else {
                String verif_pass = box_connection_pass.getText();
                rs = stmt.executeQuery("SELECT pass_util FROM Utilisateur WHERE adresse_mail='" + verif_mail + "'");
                if (rs.next()) {
                    if (!rs.getString(1).equals(verif_pass)) {
                        System.err.println("PASSWORD ERROR: Mot de passe incorrect, veuillez réessayer\n");
                    } else {
                        //Implementation a faire pour l'interface (UI) d'un utilisateur
                        //ouverture de l'UI standard utilisateur avec toute ces informations chargé de la base
                    }
                }

            }
        }

    }

    @FXML
    void inscription_util(ActionEvent event) throws SQLException, Exception {
        String nom = box_inscript_nom.getText();
        String prenom = box_inscript_prenom.getText();
        String mail = box_inscript_mail.getText();
        String pass = box_inscript_pass.getText();
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$"; //expression stricte d'une adresse mail 
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mail);
        if (matcher.matches()) {
            String id_util = UUID.randomUUID().toString().substring(0, 6); //genere un identifiant de 10 charactère unique aléatoirement. 
            Connection conn = db.activate_connection(); //Creation d'une connection a la base
            Statement stmt = conn.createStatement();       //Creation d'une requête SQL
            stmt.execute("INSERT INTO Utilisateur VALUES('" + id_util + "','" + nom + "','" + prenom + "','" + mail + "','" + pass + "')");
            conn.commit();
            System.out.println("Inscription réussie!");
        } else {
            System.err.println("Expression d'adresse mail incorrecte: veuillez saisir une adresse mail valide (ex. exemple@domaine.org)");

        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            btn_connection.setDisable(true);
            btn_inscription.setDisable(true);
            set_btn_connection_active();
            set_btn_inscript_active();
            db = new enchere_database();
            Connection conn = db.activate_connection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Utilisateur");
            while (rs.next()) {
                println_data(rs);

            }
        } catch (Exception ex) {

            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}


